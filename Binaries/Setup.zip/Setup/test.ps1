﻿
echo  starting

. "$PSScriptRoot\reusable.ps1"

#Convert-PBIRByPathToByConnection -PBIRFilePath "$PSScriptRoot\Lakehouse Maintenance Report.Report\definition.pbir" -WorkspaceName "OnyxTools" -SemanticModelId "7fcc1088-feb6-4cee-9ec0-72cb893113bb" -SemanticModelName "Lakehouse Maintenance Report"

$url=Get-FabricLakehouseUrl -WorkspaceId "0763eaca-a88e-4630-b0e3-67f5382c2105" -LakehouseId "4ad6b3dd-57a7-4d06-b3a7-edb6ac77efd5"

Update-TmdlExpressionsFile -FilePath "$PSScriptRoot\Lakehouse Maintenance Report.SemanticModel\definition\expressions.tmdl" -NewLakehouseUrl $url  -NewLakehouseName "OnyxToolsLake"
